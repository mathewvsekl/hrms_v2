<?php

// Strictly enforce typed logic for enterprise readiness
declare(strict_types=1);
date_default_timezone_set('UTC');

/**
 * Polyfill for getallheaders() for non-Apache environments (Nginx/FPM)
 */
if (!function_exists('getallheaders')) {
    function getallheaders() {
        $headers = [];
        foreach ($_SERVER as $name => $value) {
            if (substr($name, 0, 5) == 'HTTP_') {
                $headers[str_replace(' ', '-', ucwords(strtolower(str_replace('_', ' ', substr($name, 5)))))] = $value;
            }
        }
        return $headers;
    }
}

/**
 * HRMS V2 - Custom MVC Router 
 * The single global entry point intercepting and routing API calls based on URIs.
 */

// Define explicit base paths
define('BASE_PATH', __DIR__);

// Load Core Infrastructure files
require_once BASE_PATH . '/config/database.php';
require_once BASE_PATH . '/app/Core/Controller.php';
if (file_exists(BASE_PATH . '/app/Helpers/MailHelper.php')) {
    require_once BASE_PATH . '/app/Helpers/MailHelper.php';
}
if (file_exists(BASE_PATH . '/app/Helpers/CustomFieldValidator.php')) {
    require_once BASE_PATH . '/app/Helpers/CustomFieldValidator.php';
}

// Future Controllers can be explicitly mapped or dynamically autoloaded here. 
// For now, load existing ones directly.
if (file_exists(BASE_PATH . '/app/Controllers/CompanyController.php')) {
    require_once BASE_PATH . '/app/Controllers/CompanyController.php';
}
if (file_exists(BASE_PATH . '/app/Controllers/EmployeeController.php')) {
    require_once BASE_PATH . '/app/Controllers/EmployeeController.php';
}
if (file_exists(BASE_PATH . '/app/Controllers/AuthController.php')) {
    require_once BASE_PATH . '/app/Controllers/AuthController.php';
}
if (file_exists(BASE_PATH . '/app/Controllers/OrganizationController.php')) {
    require_once BASE_PATH . '/app/Controllers/OrganizationController.php';
}
if (file_exists(BASE_PATH . '/app/Middleware/AuthMiddleware.php')) {
    require_once BASE_PATH . '/app/Middleware/AuthMiddleware.php';
}
if (file_exists(BASE_PATH . '/app/Middleware/RoleMiddleware.php')) {
    require_once BASE_PATH . '/app/Middleware/RoleMiddleware.php';
}
if (file_exists(BASE_PATH . '/app/Controllers/CustomFieldController.php')) {
    require_once BASE_PATH . '/app/Controllers/CustomFieldController.php';
}
if (file_exists(BASE_PATH . '/app/Controllers/RbacController.php')) {
    require_once BASE_PATH . '/app/Controllers/RbacController.php';
}
if (file_exists(BASE_PATH . '/app/Controllers/ContractController.php')) {
    require_once BASE_PATH . '/app/Controllers/ContractController.php';
}
if (file_exists(BASE_PATH . '/app/Controllers/DocumentController.php')) {
    require_once BASE_PATH . '/app/Controllers/DocumentController.php';
}
if (file_exists(BASE_PATH . '/app/Controllers/AttendanceController.php')) {
    require_once BASE_PATH . '/app/Controllers/AttendanceController.php';
}
if (file_exists(BASE_PATH . '/app/Controllers/LeaveController.php')) {
    require_once BASE_PATH . '/app/Controllers/LeaveController.php';
}
if (file_exists(BASE_PATH . '/app/Controllers/AppraisalController.php')) {
    require_once BASE_PATH . '/app/Controllers/AppraisalController.php';
}

// Intercept Request Details
$requestUri = parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH);
$requestMethod = $_SERVER['REQUEST_METHOD'];

// Standardize route processing (strip leading slashes or prefixes if behind /HRMS V2/)
$basePrefix = '/HRMS%20V2/';
if (strpos($requestUri, $basePrefix) === 0) {
    $requestUri = substr($requestUri, strlen($basePrefix));
}

// Basic CORS Handling for Single Page Apps (Onboarding Frontend)
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: GET, POST, OPTIONS, PUT, DELETE");
header("Access-Control-Allow-Headers: Content-Type, Authorization");

if ($requestMethod == 'OPTIONS') {
    http_response_code(200);
    exit();
}

/**
 * Super Simple Router Map
 * 
 * Maps HTTP constraints to class execution.
 */
function dispatchRoute($method, $uri)
{
    // error_log("HRMS_V2 Dispatch: $method $uri");
    // Base Redirects for cleaner navigation
    if ($uri === '/' || $uri === '/dashboard') {
        header('Location: /public/index.html');
        exit();
    }
    // API: POST /api/login (Public)
    if ($method === 'POST' && strpos($uri, '/api/login') === 0) {
        $controller = new \App\Controllers\AuthController();
        return call_user_func([$controller, 'login']);
    }

    // API: POST /api/logout
    if ($method === 'POST' && strpos($uri, '/api/logout') === 0) {
        $controller = new \App\Controllers\AuthController();
        return call_user_func([$controller, 'logout']);
    }

    // API: POST /api/auth/request-otp
    if ($method === 'POST' && strpos($uri, '/api/auth/request-otp') === 0) {
        $controller = new \App\Controllers\AuthController();
        return call_user_func([$controller, 'requestOTP']);
    }

    // API: POST /api/auth/verify-otp
    if ($method === 'POST' && strpos($uri, '/api/auth/verify-otp') === 0) {
        $controller = new \App\Controllers\AuthController();
        return call_user_func([$controller, 'verifyOTP']);
    }

    // DEBUG: GET /api/debug/otp-logs (Development only)
    if ($method === 'GET' && strpos($uri, '/api/debug/otp-logs') === 0) {
        $logFile = BASE_PATH . '/tmp/mail_log.txt';
        header('Content-Type: text/plain');
        if (file_exists($logFile)) {
            readfile($logFile);
        } else {
            echo "OTP log file not found.";
        }
        exit();
    }

    // --- PROTECTED ROUTES BELOW ---
    \App\Middleware\AuthMiddleware::protect();

    // ── ORGANIZATION API ──────────────────────────────────────
    // Helper: extract numeric IDs from URI
    $orgParts = explode('/', trim($uri, '/'));
    $orgId = is_numeric(end($orgParts)) ? end($orgParts) : null;

    // For nested resources like /offices/{id}/custom_fields/{field_id}
    $numericIds = [];
    foreach ($orgParts as $part) {
        if (is_numeric($part))
            $numericIds[] = $part;
    }
    $firstNumericId = $numericIds[0] ?? null;
    $lastNumericId = end($numericIds) ?: null;

    // RBAC Permissions
    if (strpos($uri, '/api/rbac/') === 0) {
        $controller = new \App\Controllers\RbacController();
        if ($uri === '/api/rbac/roles' && $method === 'GET')
            return call_user_func([$controller, 'listRoles']);
        if ($uri === '/api/rbac/roles' && $method === 'POST')
            return call_user_func([$controller, 'createRole']);
        if ($uri === '/api/rbac/permissions' && $method === 'GET')
            return call_user_func([$controller, 'listPermissions']);

        // Roles/{id}/permissions
        if (preg_match('/\/api\/rbac\/roles\/(\d+)\/permissions/', $uri, $matches)) {
            $roleId = $matches[1];
            if ($method === 'GET')
                return call_user_func([$controller, 'getRolePermissions'], $roleId);
            if ($method === 'PUT')
                return call_user_func([$controller, 'updateRolePermissions'], $roleId);
        }

        // Roles/{id}
        if (preg_match('/\/api\/rbac\/roles\/(\d+)$/', $uri, $matches) && $method === 'DELETE') {
            return call_user_func([$controller, 'deleteRole'], $matches[1]);
        }
    }

    // Custom Fields (Nested under Companies)
    if (preg_match('/\/api\/organization\/companies\/(\d+)\/custom_fields/', $uri, $matches)) {
        $companyId = $matches[1];
        $fieldId = (count($numericIds) > 1) ? $lastNumericId : null;
        $controller = new \App\Controllers\CustomFieldController();

        if ($method === 'GET' && !$fieldId)
            return call_user_func([$controller, 'index'], $companyId);
        if ($method === 'POST')
            return call_user_func([$controller, 'store'], $companyId);
        if ($method === 'PUT' && $fieldId)
            return call_user_func([$controller, 'update'], $companyId, $fieldId);
        if ($method === 'DELETE' && $fieldId)
            return call_user_func([$controller, 'destroy'], $companyId, $fieldId);
    }

    // Countries
    if (strpos($uri, '/api/organization/countries') === 0) {
        $controller = new \App\Controllers\OrganizationController();
        if ($method === 'GET')
            return call_user_func([$controller, 'listCountries']);
        if ($method === 'POST')
            return call_user_func([$controller, 'createCountry']);
        if ($method === 'PUT' && $orgId)
            return call_user_func([$controller, 'updateCountry'], $orgId);
        if ($method === 'DELETE' && $orgId)
            return call_user_func([$controller, 'deleteCountry'], $orgId);
    }

    // Companies
    if (strpos($uri, '/api/organization/companies') === 0 && strpos($uri, 'custom_fields') === false) {
        $controller = new \App\Controllers\OrganizationController();
        if ($method === 'GET')
            return call_user_func([$controller, 'listCompanies']);
        if ($method === 'POST')
            return call_user_func([$controller, 'createCompany']);
        if ($method === 'PUT' && $orgId)
            return call_user_func([$controller, 'updateCompany'], $orgId);
        if ($method === 'DELETE' && $orgId)
            return call_user_func([$controller, 'deleteCompany'], $orgId);
    }

    // Departments
    if (strpos($uri, '/api/organization/departments') === 0) {
        $controller = new \App\Controllers\OrganizationController();
        if ($method === 'GET')
            return call_user_func([$controller, 'listDepartments']);
        if ($method === 'POST')
            return call_user_func([$controller, 'createDepartment']);
        if ($method === 'PUT' && $orgId)
            return call_user_func([$controller, 'updateDepartment'], $orgId);
        if ($method === 'DELETE' && $orgId)
            return call_user_func([$controller, 'deleteDepartment'], $orgId);
    }

    // Designations
    if (strpos($uri, '/api/organization/designations') === 0) {
        $controller = new \App\Controllers\OrganizationController();
        if ($method === 'GET')
            return call_user_func([$controller, 'listDesignations']);
        if ($method === 'POST')
            return call_user_func([$controller, 'createDesignation']);
        if ($method === 'PUT' && $orgId)
            return call_user_func([$controller, 'updateDesignation'], $orgId);
        if ($method === 'DELETE' && $orgId)
            return call_user_func([$controller, 'deleteDesignation'], $orgId);
    }

    // Global Settings
    if (strpos($uri, '/api/organization/settings') === 0) {
        $controller = new \App\Controllers\OrganizationController();
        if ($method === 'GET')
            return call_user_func([$controller, 'listSettings']);
        if ($method === 'POST')
            return call_user_func([$controller, 'updateSetting']);
    }

    // Exchange Rates
    if (strpos($uri, '/api/organization/exchange-rates') === 0) {
        $controller = new \App\Controllers\OrganizationController();
        if ($method === 'GET')
            return call_user_func([$controller, 'listExchangeRates']);
        if ($method === 'POST')
            return call_user_func([$controller, 'createExchangeRate']);
    }

    // API: POST /api/employees/onboard
    if ($method === 'POST' && strpos($uri, '/api/employees/onboard') === 0) {
        $controller = new \App\Controllers\EmployeeController();
        return call_user_func([$controller, 'onboard']); // Assuming new onboard entrypoint
    }

    // API: POST /api/employees (Onboard/Save)
    if ($method === 'POST' && strpos($uri, '/api/employees') === 0) {
        $controller = new \App\Controllers\EmployeeController();
        $requestData = json_decode(file_get_contents('php://input'), true);
        return call_user_func([$controller, 'save'], $requestData);
    }

    // API: GET /api/employees (list or single)
    if ($method === 'GET' && strpos($uri, '/api/employees') === 0) {
        $controller = new \App\Controllers\EmployeeController();
        $parts = explode('/', trim($uri, '/'));
        $id = end($parts);
        if (is_numeric($id)) {
            call_user_func([$controller, 'getEmployee'], $id);
        } else {
            call_user_func([$controller, 'listEmployees']);
        }
    }

    // API: PUT /api/employees/{id}
    if ($method === 'PUT' && strpos($uri, '/api/employees') === 0) {
        $controller = new \App\Controllers\EmployeeController();
        $parts = explode('/', trim($uri, '/'));
        $id = end($parts);
        $requestData = json_decode(file_get_contents('php://input'), true);
        if (is_numeric($id)) {
            $requestData['id'] = $id;
        }
        return call_user_func([$controller, 'updateEmployee'], $requestData);
    }

    // API: GET /api/companies/templates
    if ($method === 'GET' && strpos($uri, '/api/companies/templates') === 0) {
        $controller = new \App\Controllers\CompanyController();
        // Extract ID if provided via /api/companies/templates/X
        $parts = explode('/', trim($uri, '/'));
        $id = end($parts);
        if (is_numeric($id)) {
            return call_user_func([$controller, 'getTemplate'], $id);
        }
        return call_user_func([$controller, 'getTemplate']);
    }

    // API: GET /api/custom_fields?company_id=X
    if ($method === 'GET' && strpos($uri, '/api/custom_fields') === 0) {
        $controller = new \App\Controllers\CustomFieldController();
        $companyId = $_GET['company_id'] ?? null;
        if ($companyId) {
            $result = call_user_func([$controller, 'index'], $companyId);
            echo json_encode($result);
            exit();
        }
    }

    // API: CONTRACTS
    if (strpos($uri, '/api/contracts') === 0) {
        $controller = new \App\Controllers\ContractController();
        if ($method === 'GET') {
            $employeeId = $_GET['employee_id'] ?? null;
            return call_user_func([$controller, 'getEmployeeContracts'], $employeeId);
        } elseif ($method === 'POST') {
            $requestData = json_decode(file_get_contents('php://input'), true);
            return call_user_func([$controller, 'createContract'], $requestData);
        } elseif ($method === 'DELETE') {
            $parts = explode('/', trim($uri, '/'));
            $id = end($parts);
            return call_user_func([$controller, 'deleteContract'], $id);
        }
    }

    // API: DOCUMENTS
    if (strpos($uri, '/api/documents') === 0) {
        $controller = new \App\Controllers\DocumentController();
        if ($method === 'GET') {
            $employeeId = $_GET['employee_id'] ?? null;
            return call_user_func([$controller, 'getEmployeeDocuments'], $employeeId);
        } elseif ($method === 'POST') {
            $employeeId = $_POST['employee_id'] ?? null;
            return call_user_func([$controller, 'uploadDocument'], $employeeId);
        } elseif ($method === 'DELETE') {
            $parts = explode('/', trim($uri, '/'));
            $id = end($parts);
            return call_user_func([$controller, 'deleteDocument'], $id);
        }
    }

    // API: ATTENDANCE
    if (strpos($uri, '/api/attendance') === 0) {
        $controller = new \App\Controllers\AttendanceController();
        if ($method === 'GET') {
            if (strpos($uri, '/api/attendance/summary') === 0) {
                return call_user_func([$controller, 'getEmployeeSummary'], $_GET);
            }
            if (strpos($uri, '/api/attendance/history') === 0) {
                return call_user_func([$controller, 'getAuditHistory'], $_GET);
            }
            if (strpos($uri, '/api/attendance/countries') === 0) {
                return call_user_func([$controller, 'getCountries']);
            }
            if (strpos($uri, '/api/attendance/grid') === 0) {
                return call_user_func([$controller, 'getGridLogs'], $_GET);
            }
            return call_user_func([$controller, 'getLogs'], $_GET);

        } elseif ($method === 'POST') {
            if (strpos($uri, '/api/attendance/grid-save') === 0) {
                $requestData = json_decode(file_get_contents('php://input'), true);
                return call_user_func([$controller, 'saveGridEntries'], $requestData);
            }
            if (strpos($uri, '/api/attendance/bulk') === 0) {
                $requestData = json_decode(file_get_contents('php://input'), true);
                return call_user_func([$controller, 'saveBulkEntry'], $requestData);
            }

            if (strpos($uri, '/api/attendance/submit') === 0) {


                $requestData = json_decode(file_get_contents('php://input'), true);
                return call_user_func([$controller, 'submitLogs'], $requestData);
            }
            if (strpos($uri, '/api/attendance/review') === 0) {
                $requestData = json_decode(file_get_contents('php://input'), true);
                return call_user_func([$controller, 'reviewLogs'], $requestData);
            }
            $requestData = json_decode(file_get_contents('php://input'), true);
            return call_user_func([$controller, 'saveManualEntry'], $requestData);
        }

    }

    // API: LEAVE & HOLIDAYS
    if (strpos($uri, '/api/leave') === 0 || strpos($uri, '/api/holidays') === 0) {
        $controller = new \App\Controllers\LeaveController();

        if (strpos($uri, '/api/holidays') === 0) {
            if ($method === 'GET') {
                return call_user_func([$controller, 'getHolidays'], $_GET['company_id'] ?? null);
            } elseif ($method === 'POST') {
                $requestData = json_decode(file_get_contents('php://input'), true);
                return call_user_func([$controller, 'addHoliday'], $requestData);
            } elseif ($method === 'DELETE') {
                $parts = explode('/', trim($uri, '/'));
                $id = end($parts);
                return call_user_func([$controller, 'deleteHoliday'], $id);
            }
        }

        // Handle sub-resources for /api/leave
        if (strpos($uri, '/api/leave/approve') === 0 && $method === 'POST') {
            $requestData = json_decode(file_get_contents('php://input'), true);
            return call_user_func([$controller, 'approveRequest'], $requestData);
        }
        if (strpos($uri, '/api/leave/reject') === 0 && $method === 'POST') {
            $requestData = json_decode(file_get_contents('php://input'), true);
            return call_user_func([$controller, 'rejectRequest'], $requestData);
        }
        if (strpos($uri, '/api/leave/balances') === 0 && $method === 'GET') {
            return call_user_func([$controller, 'getBalances'], $_GET['employee_id'] ?? null);
        }
        if (strpos($uri, '/api/leave/preview') === 0 && $method === 'GET') {
            return call_user_func([$controller, 'previewLeaveDays'], $_GET);
        }
        if (strpos($uri, '/api/leave/types') === 0) {
            if ($method === 'GET') {
                return call_user_func([$controller, 'getLeaveTypes']);
            } elseif ($method === 'POST') {
                $requestData = json_decode(file_get_contents('php://input'), true);
                return call_user_func([$controller, 'addLeaveType'], $requestData);
            }
        }

        if (strpos($uri, '/api/leave/policies') === 0) {
            if ($method === 'GET') {
                return call_user_func([$controller, 'getPolicies'], $_GET['company_id'] ?? null);
            } elseif ($method === 'POST') {
                $requestData = json_decode(file_get_contents('php://input'), true);
                return call_user_func([$controller, 'savePolicy'], $requestData);
            }
        }

        if ($method === 'GET') {
            return call_user_func([$controller, 'getRequests'], $_GET);
        } elseif ($method === 'POST') {
            $requestData = json_decode(file_get_contents('php://input'), true);
            return call_user_func([$controller, 'submitRequest'], $requestData);
        }
    }

    // API: APPRAISALS
    if (strpos($uri, '/api/appraisals') === 0) {
        $controller = new \App\Controllers\AppraisalController();
        if ($method === 'GET') {
            $parts = explode('/', trim($uri, '/'));
            $action = end($parts);
            if ($action === 'template') {
                return call_user_func([$controller, 'getTemplate'], $_GET['id'] ?? null);
            }
            if (is_numeric($action)) {
                return call_user_func([$controller, 'getAppraisal'], $action);
            }
            return call_user_func([$controller, 'listAppraisals'], $_GET);
        } elseif ($method === 'POST') {
            $parts = explode('/', trim($uri, '/'));
            $action = end($parts);
            $requestData = json_decode(file_get_contents('php://input'), true);

            if ($action === 'submit-manager') {
                return call_user_func([$controller, 'submitToManager'], $parts[count($parts) - 2], $requestData);
            } elseif ($action === 'submit-hr') {
                return call_user_func([$controller, 'submitToHR'], $parts[count($parts) - 2], $requestData);
            } elseif ($action === 'finalize') {
                return call_user_func([$controller, 'finalize'], $parts[count($parts) - 2], $requestData);
            } elseif ($action === 'draft') {
                return call_user_func([$controller, 'saveDraft'], $requestData);
            }

            return call_user_func([$controller, 'saveDraft'], $requestData);
        }
    }

    // Default Fallback
    header("Content-Type: application/json; charset=UTF-8");
    http_response_code(404);
    echo json_encode([
        'status' => 'error',
        'code' => 404,
        'message' => 'API Route Not Found or Unsupported Method.'
    ]);
    exit();
}

// Execute logic loop
dispatchRoute($requestMethod, $requestUri);
