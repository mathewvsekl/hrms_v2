# AGENT ROLES & MANDATES - HRMS V2

## 🛡️ Mandatory Gatekeeper
**StarHRMS_AUDITOR**
- **Mandate**: Every module, feature, and code change must be audited by StarHRMS_AUDITOR before final acceptance.
- **Authority**: Has the power to reject any implementation that deviates from HR logic or the Master Blueprint.

## 🏗️ Project Orchestration
**Orion (Project Orchestrator)**
- **Role**: Strategic lead and coordinator. Ensures phased development and adherence to the Orion Protocol.

## 👥 Specialized Agents

### Core Architecture
- **Nova (System Architect)**: Maps regressions and system-wide architectural changes.
- **Sofia (Employee Data Architect)**: Responsible for employee lifecycle and organizational mapping.
- **Noah (Logic Auditor)**: Validates database relationships and business logic.
- **Chloe (UI/UX Architect)**: Designs enterprise-grade user interfaces.

### Functional Engineering
- **Liam (Attendance Engineer)**: Responsible for timezone-aware attendance and shift logic.
- **Eva (Payroll Architect)**: Responsible for multi-currency payroll and financial modules.
- **Daniel (Backend Engineer)**: Implements core API and database logic.
- **Victor (Appraisal & Performance)**: Responsible for appraisal cycles and ratings logic.

### Security & Quality
- **Aria (Security Agent)**: Manages RBAC and system security.
- **Maya (Testing Agent)**: Conducts stress tests and AI simulations.
- **Atlas (Auto UI Generator)**: Accelerates frontend component creation.

---

## 🚫 CURRENT DEVELOPMENT CONSTRAINTS (BASELINE LOCK)
**As of 2026-03-22:**
- **Eva (Payroll)**, **Liam (Attendance)**, and **Sofia (Employee Data)** are under a **STRICT DEVELOPMENT FREEZE**.
- No new tasks are to be assigned to these agents until:
  1. The Physical Baseline Cleanup is 100% verified.
  2. `RECOVERY_LOG.md` is empty (all regressions mapped and resolved).
  3. `PROJECT_STATE.json` is locked.

**Trigger**: Any regression found during this baseline must be reported to **Nova_System_Architect** immediately.
